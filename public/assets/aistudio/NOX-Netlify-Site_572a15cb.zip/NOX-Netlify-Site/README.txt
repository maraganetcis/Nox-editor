NOX Netlify Site

Deployment:
1. Extract this ZIP.
2. Open https://app.netlify.com/drop
3. Upload the extracted folder containing index.html (or drag the folder into Netlify Drop).
4. Open the generated *.netlify.app URL.

This is an early browser-based NOX interpreter subset. It is not the full Python interpreter.
